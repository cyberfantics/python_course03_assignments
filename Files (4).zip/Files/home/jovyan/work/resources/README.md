Place anything that is not a graded assignment, secret, or readonly in here.
